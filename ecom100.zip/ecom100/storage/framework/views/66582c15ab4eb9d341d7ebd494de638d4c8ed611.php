<html>
	<head>
		<title>Contact Email</title>
	</head>
	<body>
		<table>
			<tr><td>Dear Admin</td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td>User enquiry Details are as below:</td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td>Name: <?php echo e($name); ?></td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Email: <?php echo e($email); ?></td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Subject: <?php echo e($subject); ?></td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td>Message:<?php echo e($comment); ?></td></tr>
			<tr><td>&nbsp;</td></tr>
	</body>
</html>