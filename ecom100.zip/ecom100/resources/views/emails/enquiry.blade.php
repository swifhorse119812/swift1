<html>
	<head>
		<title>Contact Email</title>
	</head>
	<body>
		<table>
			<tr><td>Dear Admin</td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td>User enquiry Details are as below:</td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td>Name: {{ $name }}</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Email: {{ $email }}</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Subject: {{ $subject }}</td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td>Message:{{ $comment }}</td></tr>
			<tr><td>&nbsp;</td></tr>
	</body>
</html>